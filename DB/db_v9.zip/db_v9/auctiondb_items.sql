-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: auctiondb
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `currently` int NOT NULL,
  `buy_price` int NOT NULL,
  `first_bid` int NOT NULL,
  `number_of_bids` int NOT NULL,
  `starts` datetime NOT NULL,
  `ends` datetime NOT NULL,
  `description` longtext,
  `location` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `bidder_rating` int NOT NULL,
  `seller_rating` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_bids_user_idx` (`users_id`),
  CONSTRAINT `fk_items_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,12,'Mighty Painting',250,300,100,5,'2022-01-03 13:32:14','2022-01-19 22:17:05','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.Â ','Louvre Museum','France',48.86133,2.33756,0,0),(2,10,'Blue Couch',300,400,120,8,'2022-01-16 22:19:18','2022-02-14 18:17:47',NULL,'IKEA','USA',40.67198,-74.01145,0,0),(3,2,'Oak Desk',500,600,340,6,'2022-02-21 09:25:06','2022-03-04 21:44:57','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.','IKEA','Greece',37.98138,23.67915,0,0),(4,2,'BMW Car',18000,18000,10000,7,'2022-03-04 21:44:57','2022-04-22 21:03:19',NULL,'BMW Munich','Germany',48.18804,11.57409,5,2),(5,2,'Old Laptop',600,700,500,17,'2022-05-01 04:36:00','2022-08-21 06:28:16','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.','Πλαίσιο Περιστερίου','Greece',38.01322,23.69103,0,0),(6,13,'Collectors Pokemon Cards',2600,3000,820,15,'2022-06-21 05:47:29','2022-08-25 19:39:28','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat. ','2 Chome-1-11 Shibaura','Japan',35.64551,139.75485,0,0),(7,9,'Black Troufle',0,700,340,0,'2022-07-24 15:01:50','2022-07-29 03:25:13','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat. ','Sublimotion','Spain',38.88404,1.4027,0,0),(8,14,'Black Couch',0,900,345,0,'2022-07-29 09:06:15','2022-08-02 06:18:52',NULL,NULL,NULL,NULL,NULL,0,0),(9,8,'Small Fridge',500,500,240,1,'2022-08-03 04:21:45','2022-09-08 16:22:58','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat. ','Gemla Fabrikers AB','Sweden',56.63984,14.21631,0,0),(10,9,'Gamer RGB PC',0,8000,7000,0,'2022-09-13 12:32:03','2022-09-14 08:14:10','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.Â ','Compliq IT AB','Sweden',55.71987,13.20771,0,0),(11,6,'Anda Seat',0,680,500,0,'2022-09-10 07:45:18','2022-09-24 23:02:41','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat. ','Anda Seat','Canada',43.85882,-79.38728,0,0),(12,9,'Electric Bike',0,2000,1500,0,'2022-09-24 10:33:36','2022-09-27 17:29:24','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.Â ','Tesla','Canada',43.4485,-79.69573,0,0),(14,11,'Bulls First Row Tickets',0,300,100,0,'2022-10-11 07:41:37','2022-10-18 09:35:51',NULL,'United Center','USA',41.88071,-87.67414,0,0),(15,8,'Collectors Yu-Gi-Oh Cards',0,900,50,0,'2022-10-24 23:32:34','2022-12-17 19:39:33',NULL,'BIE KABUSHIKI GAISHA','Japan',35.7885,139.89609,0,0),(16,14,'King Size Bed',0,2800,1000,0,'2022-12-12 00:16:17','2022-12-22 20:36:10','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.','IKEA Rothenburg','Switzerland',47.09755,8.24331,0,0),(17,11,'Life Time Supply Dorritos',0,3000,1500,0,'2022-08-01 00:20:00','2022-09-01 00:20:01','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nisi neque, aliquam et blandit eget, lobortis a nunc. Mauris aliquam a libero mollis imperdiet. Donec vitae ligula efficitur, vulputate lorem eu, ullamcorper elit. Cras semper, turpis eget elementum placerat, urna metus tristique metus, in venenatis odio nisl ut lacus. Nam porttitor aliquam sem sed aliquet. Mauris eu leo quis augue pharetra gravida feugiat sed sapien. Maecenas fermentum, neque ultricies tincidunt lobortis, quam arcu vestibulum dolor, eu porta metus risus sit amet diam. Praesent vehicula risus non justo tempor placerat.','Veteran Chuishiban','China',30.5893,114.29106,0,0),(20,21,'Table1',800,800,100,2,'2022-09-01 13:56:00','2022-09-19 13:57:00','Table1 auction','Address01','Greece',42.15555865344159,23.511460986503558,0,0);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-20 19:28:26
