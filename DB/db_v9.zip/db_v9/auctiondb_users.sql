-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: auctiondb
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `username` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Saving as plain text. Will use protocol.',
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Saving as plain text. Will use protocol.',
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `surname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `email` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `phone` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `afm` varchar(45) NOT NULL,
  `balance` double NOT NULL,
  `rating_seller` float NOT NULL,
  `total_ratings_seller` int NOT NULL,
  `rating_buyer` float NOT NULL,
  `total_ratings_buyer` int NOT NULL,
  `status` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Status = ["waiting", "approved", "blocked", "admin"]',
  PRIMARY KEY (`id`),
  KEY `users_FK` (`role_id`),
  CONSTRAINT `users_FK` FOREIGN KEY (`role_id`) REFERENCES `authorities` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'fletchingcarry','$2a$10$Qj8lZGsMjsT7kB1vgmOJJeczS6.YbZjvX9YH4z6Jdedqd9IB5MASG','Ned','Arias','Εθνική Πινακοθήκη',37.97574,23.74941,'maeegoistic@att.net','(541) 734-3576','977737114',511,3.9,68,4,47,'approved'),(2,1,'draughtgrist','$2a$10$zW1u8c1W2c2CtAEUuyT2rOCVg0x83561Ui0fz0QhSe42kstDyk0IC','Priyanka','Armenta','Kalavriton 2',37.514887,22.37479,'toninerd@msn.com','(570) 963-0814','181517382',16.28,2.95555,45,3.06667,30,'approved'),(3,1,'pretzelscorched','$2a$10$HaIA4cFuTXgrqbnxt8JnvuKne9kyafLAkaDT/UqsNFXNIazWqB9GO','Micheal','Armijo','Ipsilantou 63-59',39.363337,21.929087,'worriedmaxie@live.com','(869) 763-7179','901910209',486.95,1,27,1,72,'approved'),(4,1,'chivalrousbit','$2a$10$6gyHY5cZLlgZIXNNN9ml8O.SEkigF7B25pb2tvV8dAlDD7io06Qn.','Brianna','Armstead','Filippou 31-23',40.638007,22.944057,'perpetratedental@msn.com','(641) 696-3176','233366386',454.87,3,78,2,68,'approved'),(5,1,'dronerain','$2a$10$3S6BtNB6z6a1o7w7.dlCFedmLtHw/idTRClErMjnTzHFn7Lb8zsuq','Jenny','Armstrong','Marias Gouroufidou 11-1',40.657682,22.908068,'fayesweet@yahoo.com','(801) 205-9981','536619504',443.73,5,65,1,32,'waiting'),(6,1,'gildcrabby','$2a$10$x/ZSSFogJVQZ33B26tpQ8uGVPR.fWafeQiJ.ZYNVbDf/KxuzBx2ou','Daryl','Arndt','25is Martiou 24',40.68823,22.84586,'cheerfuleli@att.net','(316) 382-1672','973317023',321.56,5,61,4,71,'waiting'),(7,1,'milksopbold','$2a$10$otijtroGh7FxkHrk.h.yJuXBPEGQKO83wywpAKvI8Z0WuRD/XS.t2','Daniella','Arnett','Sokratous 177',37.94702,23.70062,'dislikedsawney@msn.com','(462) 518-1189','630084975',201,4,28,4,37,'waiting'),(8,1,'fixedplastic','$2a$10$Z1b57DqqLNXrEq.ZpyMeDOYpG.UZuqkK.W.cGa5Ix7dFTpawJzW8e','Jake','Arnold','Ellispontou 11',37.963308,23.627754,'grillable@att.net','(304) 666-0177','584177094',320.43,1,36,3,74,'waiting'),(9,1,'controlnappy','$2a$10$qJbhfY8wfBDFfQwBV/yRtO/QIm4m/MYifRew/uU9C43KU26aWLpc2','Lachlan','Arredondo','Panagias Marmariotissis 5-3',38.016338,23.795721,'hattiebrooding@yahoo.ca','(641) 696-3176','177282501',322,2,23,5,33,'waiting'),(10,1,'dreamjudo','$2a$10$13PhPJzSeg1AQPSE30oCPelLfeQk7PyyyALpbixgWcO71FGQ2jXcW','Evie-Mae','Arreola','Voreiou Ipeirou 115',38.038864,23.685648,'resentfulkristy@mac.com','(801) 205-9981','251028936',11.1,5,63,3,44,'blocked'),(11,1,'corruptcandycane','$2a$10$HTOew6J85yUrvqtyQPhw1OjlMhnKqmrXvBr7q9jc0tTkhWxA5n0XC','Najma','Arriaga','Solomou 7',39.65987,20.85485,'marshalbroken@msn.com','(316) 382-1672','192793504',1000,4,36,4,33,'approved'),(12,1,'coterielaveer','$2a$10$NMubTIT4hi92YZYZDuIHdOGZFst0M2otXEgdX.ZB4x7rbAytZR58W','Sylvie','Arroyo','Agiou Nikonos 87-77',37.075974,22.431075,'solveoutlandish@icloud.com','(462) 518-1189','554100528',221.1,3,96,2.0122,82,'approved'),(13,1,'folkreiterate','$2a$10$2KZg5Bg1RG1JGf6SHEl0.u9jmHgFYEPd631X5DuMWHilCCnACvaVC','Bhavik','Arsenault','Tomara 5',37.82179,22.661031,'alparanoid@hotmail.com','(304) 666-0177','286791469',303.16,1,51,1,89,'approved'),(14,1,'loosegrizzled','$2a$10$eYbtoiIVRpHq1t/67/AF/u4/e5voFJfnxVUFKGimyma8Raxk1wqOa','Aneesah','Arteaga','Athanasiou Diakou 13',40.517275,22.204926,'barkknowing@yahoo.com','(869) 763-7179','483638592',457.22,3,99,4,52,'approved'),(15,2,'admin','$2a$10$ZCn1FoV0r3sb7OZLQPAxCu9J1apcsE5nDk.IG8BKCGLwmV58J1cFu','admin','admin','Dimokratias 31-27',40.676319,22.918413,'admin@admin.gr','1234567890','123456789',0,5,0,5,0,'admin'),(18,1,'loukas438','$2a$10$NMFeUWyc8hLaVs9RY.JtGeiDQMR6aT6VvhKmyXrFRRhVwu6a7u7SG','loukas','mastoropoulos','Dyrrachiou 41',38.04966,23.70245,'test@mail.com','6942952497','111222333',2000,0,0,0,0,'approved'),(19,1,'player01','$2a$10$Wv8da9LcROBneKdkczddh.3f666wiKE2ifvqI3B4uIedsgj/u8/kO','Player','One','address1',36.130744126572104,24.68635197120797,'player1@mail.com','phone1','1111',10000,0,0,0,0,'approved'),(20,1,'player02','$2a$10$n1GN5Gz8aeMkvnA0f2FJmuBHjZ0bCTD1P8vneSBgVCL.4BeKDSFgu','Player','Two','address2',35.47801088716723,29.058359921000715,'player2@mail.com','phone2','2222',10000,0,0,0,0,'approved'),(21,1,'player03','$2a$10$kmCxvzAbO1SyUUxBYOTcEutL2R7QRuHELRRrSD/vcEjGpMpNKyhPS','Player','Three','address3',35.87241948857142,28.510280390190836,'player3@mail.com','phone3','3333φ',9150,0,0,0,0,'approved');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-20 19:28:25
